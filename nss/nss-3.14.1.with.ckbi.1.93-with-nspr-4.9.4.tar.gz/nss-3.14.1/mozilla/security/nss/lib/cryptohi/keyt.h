/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
/* $Id: keyt.h,v 1.5 2012/04/25 14:49:41 gerv%gerv.net Exp $ */

#ifndef _KEYT_H_
#define _KEYT_H_

#include "keythi.h"

#endif /* _KEYT_H_ */
